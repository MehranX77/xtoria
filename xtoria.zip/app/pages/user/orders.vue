<template>
    <div class="flex flex-col gap-y-3">
        <h2 class="dark:text-slate-200 text-slate-700  lg:text-2xl font-bold mt-5">مدیریت سفارشات</h2>
        <div v-if="res?.data?.results" class="flex flex-col gap-y-3 mt-5">
            <!-- i must set v-for on this component for render data -->
            <UCard v-for="product in res?.data?.results" :key="product.id">
                <template #header>
                   <div class="flex justify-between">
                    <p class="font-bold dark:text-slate-200 text-slate-700 text-md">سفارش 1257#</p>
                    <UBadge color="secondary">در حال پردازش</UBadge>
                   </div>
                </template>
                <template #default>
                    <div class="flex justify-between">
                        <div class="flex gap-x-4">
                           <NuxtImg class="w-20 max-w-20 h-20 max-h-20" src="case.png"/>
                           <span class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">کیس گیمینگ</span>
                        </div>

                        <span class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">قیمت: 200/000 تومان</span>
                        <span class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">تعداد: 1</span>
                        <span class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">تخفیف: 5%</span>
                        <span class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">قیمت نهایی: 200/000 تومان</span>
                    </div>
                    <USeparator />
                       <div class="flex justify-between mt-3">
                        <div class="flex gap-x-4">
                           <NuxtImg class="w-20 max-w-20 h-20 max-h-20" src="mouse.png"/>
                           <span class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">کیس گیمینگ</span>
                        </div>

                        <span class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">قیمت: 200/000 تومان</span>
                        <span class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">تعداد: 1</span>
                        <span class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">تخفیف: 5%</span>
                        <span class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">قیمت نهایی: 200/000 تومان</span>
                    </div>
                </template>
                <template #footer>
                    <div class="flex justify-between">
                        <UButton color="neutral" variant="subtle" size="lg">پیگیری سفارش</UButton>
                        <p class="dark:text-slate-200 text-slate-600 text-md font-bold self-center">مجموع قیمت: 400/000 تومان</p>
                    </div>
                </template>
            </UCard>
            <!-- end data rendered -->
        </div>
        <div v-else class="flex flex-col gap-y-5 justify-center items-center h-full">
          <UIcon class="text-5xl text-slate-400 dark:text-slate-600" name="line-md:moon-alt-twotone-loop"/>
          <p class="font-black text-muted">تاکنون سفارشی ثبت نشده!</p>
        </div>
    </div>

</template>

<script setup lang="ts">
useHead({
  title:'سفارشات'
})
const headers = useRequestHeaders(['cookie'])
try {
    const res = await $fetch('/api/order-list', {
        method:'GET',
        headers
    })

    console.log(res);
    
} catch (error) {
    console.log(error);
    
}





</script>