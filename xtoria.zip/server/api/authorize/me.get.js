import { defineEventHandler, getCookie } from "#imports"
const { public: { baseURL } } = useRuntimeConfig()
export default defineEventHandler(async (event) => {
    const token = getCookie(event, 'access-token')    
    try {
        const res = await $fetch(`${baseURL}/account/profile`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })

        if (res.status === 200) {
            return res
        } else if (res.status === 401 || res.status === 400) {
            deleteCookie(event, 'access-token', {
                path: '/',
                secure: true,
                sameSite:'lax',
                httpOnly: true,
            })
            deleteCookie(event, 'refresh-token', {
                path: '/',
                secure: true,
                sameSite:'lax',
                httpOnly: true,
            })
        }
    } catch (error) {
        return error

    }
})